<?php

/**
 * 
 */
class Database
{
	
	private $con;
	public function connect(){
		$this->con = new Mysqli("localhost", "codegwvw_ec2", "hardwork@123", "codegwvw_ec2");
		return $this->con;
	}
}

?>