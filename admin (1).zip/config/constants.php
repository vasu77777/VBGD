<?php

define('HOST', 'localhost');
define('USER', 'codegwvw_ec2');
define('PASSWORD', 'hardwork@123');
define('DATABASE_NAME', 'codegwvw_ec2');

define('CURRENCY', '$');



?>